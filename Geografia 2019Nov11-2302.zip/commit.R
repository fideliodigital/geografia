wd = "~/Fidelio/PayU/Geografía/"
gitd <- "geografia/"
site <- "_site/"
setwd(wd)

rmarkdown::render_site()

f <- paste0("Geografia ", format(Sys.time(), "%Y%b%d-%H%M"), ".zip")
setwd(site)
files2zip <- dir(full.names = TRUE, recursive = T)
zip(zipfile = f, files = files2zip)
setwd(wd)

# ---- Upload to Google Drive ----

# require(googledrive)
# googledrive::drive_upload(
#   media = paste0(site, f)
#   , path = "Fidelio/Proyectos/PayU/75B. PayU - Operación Marketing Piezas/[76011] Geografía de pagos"
#   )

# ---- Update to Github ----
file.copy(from = paste0(site, f), to = gitd)
unlink(paste0(site, f)) # borrar archivo
unzip(zipfile = paste0(gitd, f), exdir = gitd)
unlink(paste0(gitd, f)) # borrar archivo

# fileConn<-file(paste0(gitd,"CNAME"))
# write("payu.hvmmapping.fidelio.com.co", fileConn)
# close(fileConn)

# ---- Update Git Status ----

setwd(paste0(wd, gitd))
system("pwd")
system("git status")
system("git add * ")
system(sprintf('git commit -m "Update %s"', Sys.Date()))
system("git pull")
system('git push origin master')

setwd(wd)
unlink(site, recursive = T) # borrar archivo

