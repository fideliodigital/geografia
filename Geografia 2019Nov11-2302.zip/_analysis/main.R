require(plotly)
require(data.table)
library(dplyr)

# To render whole site: rmarkdown::render_site()

deptos_shape_path <- "/home/camilo/CRISP-DM/Shapes/depto/depto.shp"
stock_path = "/home/camilo/CRISP-DM/R/"
path = "~/Fidelio/PayU/Geografía/"
cities_path <- "/home/camilo/CRISP-DM/R/ColombianCities.R"
setwd(path)

source(file = cities_path, local = T, encoding = "utf-8") # Shapes
source(file = paste0(stock_path, "summary_table.R"), local = T, encoding = "utf-8") # Top Categories
source(file = paste0(stock_path, "Plots/plot_double_pie.R"), local = T, encoding = "utf-8") # Top Categories
source(file = paste0(stock_path, "Plots/plot_stacked_bar.R"), local = T, encoding = "utf-8") # Top Categories
source(file = paste0(stock_path, "Plots/plot_change.R"), local = T, encoding = "utf-8") # Top Categories

d <- readRDS("_data/data.RDS")
dptos <- set_shape(deptos_shape_path)

# ---- 3. Colombia's payment methods ----
summary_table(d = d
  , category_ = "payment_method"
  , categoricals = c("industry", "Departamento", "Ciudad")
  , numerical = "tpv"
)

plot_double_pie(d
  , category_ = "payment_method"
  , two_cat_ = "year"
  , num_ = "tpv"
)

plot_stacked_bar(d, cat1_ = "month", num1_ = "tpv", cat2_ = "payment_category")

plot_change(d, num1_ = "tpv", two_cat_ = "year", cat1_ = "industry", cat2_ = "payment_method")

# ---- 4. Colombia's regions ----
summary_table(d = d
  , category_ = "Departamento"
  , categoricals = c("industry", "payment_method", "Ciudad")
  , numerical = "tpv"
)

# ---- 5. Colombia's industries ----
summary_table(d = d
  , category_ = "industry"
  , categoricals = c("payment_method", "Departamento", "Ciudad")
  , numerical = "tpv"
)



# Omitir columnas sensibles



# Gráfica del delta de TPV

# https://www.r-graph-gallery.com/treemap.html

# ---- 2. Colombia Regions ----

# Filtro para esta sección
logic <- !is.na(d$id_mpio) &
  (d$month < "2019-10-01" & d$month >= "2019-01-01")

# Ticket promedio por departamento
ticket <- d[logic, .(
  TPT = sum(tpt, na.rm = T)
  , `Sum TPV` = sum(tpv, na.rm = T)
  , `Avg TPV` = sum(tpv, na.rm = T)/sum(tpt, na.rm = T)
), keyby = .(DPTO = id_depto, Departamento)]
dptos <- merge(x = dptos, y = ticket, by = "DPTO")
plot_shape(dptos, label = "NOMBRE_DPT", color = "Avg TPV")
# plot_shape(dptos, label = "NOMBRE_DPT", color = "TPV_sum")


# Year2Date by Departament
logic <- !is.na(d$id_mpio) &
  (d$month < "2019-07-01" & d$month >= "2019-01-01") |
  (d$month < "2018-07-01" & d$month >= "2018-01-01")
tmp <- d[logic & !is.na(id_depto), .(
  TPV_avg = sum(tpv, na.rm = T)/sum(tpt, na.rm = T)
), keyby = .(DPTO = id_depto, year)]
tmp <- dcast.data.table(data = tmp, formula = "DPTO ~ year", fun.aggregate = function(x){x[1]}, value.var = "TPV_avg")
tmp[, delta := (`2019` - `2018`)/`2018`]
tmp[`2018` == 0 | `2019` == 0, delta := NA]
dptos <- merge(x = dptos, y = tmp[, .(DPTO, delta)], by = "DPTO")
plot_shape(dptos, label = "NOMBRE_DPT", color = "delta")


# ---- Timedelta ----




# ---- Payment Method ----


# Ticket promedio por medio de pago
tmp <- d[logic, .(
  TPT = sum(tpt, na.rm = T)
  , `Sum TPV` = sum(tpv, na.rm = T)
  , `Avg TPV` = sum(tpv, na.rm = T)/sum(tpt, na.rm = T)
), keyby = .(payment_method)]

# Medios de pago más utilizados por departamento
tmp2 <- d[logic & !is.na(Departamento) & !Departamento %in% "", .(
  `Sum TPV` = sum(tpv, na.rm = T)
), keyby = .(Departamento, payment_method)][order(`Sum TPV`, decreasing = T)]
tmp2 <- tmp2[, .(`Top 3 Departaments` = top_(Departamento, `Sum TPV`)), keyby = .(payment_method)]
tmp <- tmp[tmp2]

tmp

