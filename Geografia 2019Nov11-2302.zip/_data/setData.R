require(googledrive)
require(data.table)
require(xlsx)
require(plotly)
require(readxl)
options(httr_oob_default=TRUE) 
# gs_auth(new_user = T)

setwd(dir = "/home/camilo/Fidelio/PayU/Geografía")

cities_path <- "/home/camilo/CRISP-DM/R/ColombianCities.R"
shapes_path <- "/home/camilo/CRISP-DM/R/shapes.R"
deptos_shape_path <- "/home/camilo/CRISP-DM/Shapes/depto/depto.shp"
mpios_shape_path <- "/home/camilo/CRISP-DM/Shapes/mpio/mpio.shp"
filename <- "_data/input.RDS"

source(file = cities_path, local = T, encoding = "utf-8")
source(file = shapes_path, local = T, encoding = "utf-8")

wrap <- function(d, by){
  d[, .(
    N = .N
    , tpt = sum(tpt)
    , tpv = sum(tpv)
    , tpt_perc = round(100*sum(tpt)/sum(d$tpt), 1)
    , tpv_perc = round(100*sum(tpv)/sum(d$tpv), 1)
  ) , keyby = by][order(tpv_perc, decreasing = T)] # Todos son CO.
}

# ---- Data Downloading ----
# googledrive::drive_download(as_id("1PBfYKS3VB2ZFY8XzLWpuv2nS6IkXjtYG"), path = filename,  overwrite = T)

# ---- Data Reading ----
d <- readRDS(file = filename)
# Set column names
str(d)
colnames(d)
setnames(x = d, old = "dt_app", new = "date")
setnames(x = d, old = "descripcion", new = "industry")
setnames(x = d, old = "comprador_direccion_ciudad", new = "city")
setnames(x = d, old = "country", new = "country")
setnames(x = d, old = "tx_type", new = "type")
setnames(x = d, old = "tx_status", new = "status")
setnames(x = d, old = "payment_method_detail", new = "payment_method")
setnames(x = d, old = "Tpt", new = "tpt")
setnames(x = d, old = "Tpv", new = "tpv")

# ---- Data Understanding ----
d[, month := format(as.Date(x = date, origin = "1899-12-30"), "%Y-%m")]

# Understand data table
str(d)
colnames(d)
wrap(d, "year")
wrap(d, "month")
wrap(d[year %in% "2018"], "industry")
wrap(d[year %in% "2019"], "industry")
wrap(d, "city")
wrap(d, "country") # All are CO
wrap(d, "type")
wrap(d, "status") # All are APPROVED
wrap(d, "payment_method") # Erase "TEST_CASH", "TEST_CREDIT_CARD", "ELO"
plot_ly(data = d[sample(nrow(d), size = 5000),]
        , x = ~tpv, y  = ~tpt, color = ~payment_method)

# Understand all colombian departaments
dptos <- set_shape(deptos_shape_path)
dt_shape(dptos)
plot_shape(shape = dptos, label = "NOMBRE_DPT", color = "HECTARES")

# # Understand all colombian cities
# mpios <- get_mpios_shape(mpios_shape_path)
# plot_shape(shape = mpios, label = "NOMBRE_MPI", color = "valor_agregado_MMCOP", logarithm = T)

# ---- Data Cleaning ----

# Clean unique value columns
d$date <- NULL
d$country <- NULL # Todos son CO. 
d$status <- NULL # Todos son COP.

# Clean Test Cash and Credit Card
d <- d[!payment_method %in% c("TEST_CASH", "TEST_CREDIT_CARD", "ELO"),]

# Clean data from October 2019
d <- d[!month %in% "2019-10"]

# Clean null payment methods, tpv and tpt
d <- d[!is.na(payment_method)]
d <- d[!is.na(tpv)]
d <- d[!is.na(tpt)]

# Set id for each row
d <- d[order(month)]
d$id <- seq(1:nrow(d))
setkey(d, id)

# Categorización de los métodos de pago
d[payment_method %in% c("VISA", "MASTERCARD", "DINERS", "AMEX", "CMR", "CODENSA")
  , payment_category := "Credit Card"]

d[payment_method %in% c("PSE",  "VISA_DEBIT", "ACH_DEBIT")
  , payment_category := "Debit Account"]

d[payment_method %in% c("EFECTY", "BALOTO", "OTHERS_CASH", "BANK_TRANSFER")
  , payment_category := "Cash"]

d[payment_method %in% c("BANK_REFERENCED")
  , payment_category := "Bank Referenced"]

d[payment_method %in% c("LENDING", "CASH_ON_DELIVERY")
  , payment_category := "Alternative"]
d[, .N, keyby = payment_category]

# Traducción en las industrias

d[, .N, industry]
d[grepl("Publicaciones y papeler", industry), industry := "Publications and stationery" ]
d[grepl("blicos e impuestos", industry), industry := "Public services and taxes"]

# Clean cities
variable = "city"
d <- colombian_cities(d = d, variable = variable)
d[sample(nrow(d), size = 100), .(city, Ciudad)][!is.na(city)]

# to_clean <- d[!(checked), .N, keyby = c(variable, "Ciudad")][order(N, decreasing = T)]
# cleaned <- d[(checked), .N, keyby = c(variable, "Ciudad")][order(N, decreasing = T)]
# write.xlsx(to_clean, file = "_data/Geografia_Datos.xlsx", sheetName = "Por limpiar", append = T)
# write.xlsx(cleaned, file = "_data/Geografia_Datos.xlsx", sheetName = "Limpios", append = T)


# TODO:
# 1. Categorizar las ciudades que no quedaron categorizadas.

saveRDS(d, file = "_data/data.RDS")
